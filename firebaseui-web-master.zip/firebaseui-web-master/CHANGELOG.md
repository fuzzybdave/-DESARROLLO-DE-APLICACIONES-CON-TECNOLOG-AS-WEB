* Fix password policy error message handling in password reset flow (#1047)
